//
//  Models.cpp
//
//  Assignment-specific code for objects.
//  Tessellate a plane.
//
//  Created by Warren R. Carithers on 2021/09/02.
//  Based on earlier versions created by Joe Geigel and Warren R. Carithers
//  Copyright 2021 Rochester Institute of Technology. All rights reserved.
//
//  @author  Bradley Klemick
//  @author  Michael Lee
//  @author  Dhrushit Raval
//

#include <iostream>
#include <cmath>

#if defined(_WIN32) || defined(_WIN64)
#include <windows.h>
#endif

#include "Models.h"

using namespace std;

///
/// addTriangle - add a single triangle, including points, normals, and uvs
///
/// @param C - the Canvas to use when drawing
/// @param u1 - the u coordinate for points 1 and 2
/// @param u2 - the u coordinate for point 3
/// @param v1 - the v coordinate for points 1 and 3
/// @param v2 - the v coordinate for point 2
///
void addTriangle(Canvas &C, float u1, float u2, float v1, float v2) {
    float x1 = u1 - 0.5f;
    float x2 = u2 - 0.5f;
    float y1 = v1 - 0.5f;
    float y2 = v2 - 0.5f;

    Normal planeNorm = {0.0f, 0.0f, 1.0f};

    Vertex p1 = {x1, y1, 0.0f};
    Vertex p2 = {x1, y2, 0.0f};
    Vertex p3 = {x2, y1, 0.0f};

    C.addTriangleWithNorms(p1, planeNorm, p2, planeNorm, p3, planeNorm);

    TexCoord tex1 = {u1, v1};
    TexCoord tex2 = {u1, v2};
    TexCoord tex3 = {u2, v1};

    C.addTextureCoords(tex1, tex2, tex3);
}

//
// PUBLIC FUNCTIONS
//

///
/// createObject - create our Quad object
///
/// @param C      - the Canvas to use when drawing
/// @param tessFactor - number of times to subdivide each axis
///
void createObject( Canvas &C, int tessFactor )
{
    // Loop tessFactor times along x axis
    for (int i = 0; i < tessFactor; i++) {
        float lowU = 1.0f * i / tessFactor;
        float highU = 1.0f * (i + 1) / tessFactor;
        // Loop tessFactor times along y axis
        for (int j = 0; j < tessFactor; j++) {
            float lowV = 1.0f * j / tessFactor;
            float highV = 1.0f * (j + 1) / tessFactor;

            // Create two triangles
            addTriangle(C, lowU, highU, lowV, highV);
            addTriangle(C, highU, lowU, highV, lowV);
        }
    }
}
